#!/bin/sh

kafka-server-start /usr/local/etc/kafka/server.properties