#!/bin/sh

zkServer stop