#!/bin/sh

kafka-server-stop
