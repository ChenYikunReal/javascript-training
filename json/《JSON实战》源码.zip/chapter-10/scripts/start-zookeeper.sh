#!/bin/sh

zkServer start