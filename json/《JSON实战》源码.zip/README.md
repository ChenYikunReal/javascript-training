JSON at Work
============

[![Join the chat at https://gitter.im/tmarrs/json-at-work-examples](https://badges.gitter.im/Join%20Chat.svg)](https://gitter.im/tmarrs/json-at-work-examples?utm_source=badge&utm_medium=badge&utm_campaign=pr-badge&utm_content=badge)
Code examples for __JSON at Work__, [O'Reilly Media](http://www.oreilly.com/).
