Chapter 3 Code
==============
Code examples for Chapter 3 of [__JSON at Work__](https://github.com/tmarrs/json-at-work-examples/blob/master/README.md).
