Chapter 7 Code
==============
Code examples for Chapter 7 of [__JSON at Work__](https://github.com/tmarrs/json-at-work-examples/blob/master/README.md).
