db.speakers.insert({
  fullName: 'Carl ClojureDev',
  tags: ['Clojure', 'Functional Programming'],
  age: 45,
  registered: false
})

db.speakers.find()
db.speakers.count()
