const { lcs } = PacktDataStructuresAlgorithms;
const { lcsPrint } = PacktDataStructuresAlgorithms;

const wordX = 'acbaed';
const wordY = 'abcadf';

console.log('lcs', lcs(wordX, wordY));
console.log('lcsPrint', lcsPrint(wordX, wordY));
