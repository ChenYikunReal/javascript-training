export const circleArea = r => 3.14 * (r ** 2);

export const squareArea = s => s * s;

// export { circleArea, squareArea }; // {1}
export { circleArea as circle, squareArea as square };
