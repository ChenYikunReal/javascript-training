import { binarySearchRecursive } from '../../../../src/js/index';
import { testSearchAlgorithm } from './search-algorithms-tests';

testSearchAlgorithm(binarySearchRecursive, 'Binary Search Recursive');

