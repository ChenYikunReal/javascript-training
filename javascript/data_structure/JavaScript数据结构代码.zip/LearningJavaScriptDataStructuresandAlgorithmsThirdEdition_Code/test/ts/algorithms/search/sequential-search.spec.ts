import { sequentialSearch } from '../../../../src/ts/index';
import { testSearchAlgorithm } from './search-algorithms-tests';

testSearchAlgorithm(sequentialSearch, 'Sequential Search');

