import { binarySearch } from '../../../../src/ts/index';
import { testSearchAlgorithm } from './search-algorithms-tests';

testSearchAlgorithm(binarySearch, 'Binary Search');

