import { insertionSort } from '../../../../src/ts/index';
import { testSortAlgorithm } from './sort-algorithm-tests';

testSortAlgorithm(insertionSort, 'Insertion Sort');

